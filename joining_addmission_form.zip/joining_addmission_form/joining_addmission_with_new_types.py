studentcount=1
import csv
def joiningfunc():
    fieldname =["name","branch","year","gender"]
    name=input("your name please..\t")
    branch=input("your branch please..\t")
    year=input("your year please..\t")
    gender=input("your gender..")

    global studentcount
    studentcount+=1
    li=[name,branch,year,gender]
    studentdata.append(li)
                  

    with open("studentdata.csv","w") as csvfile:
     writer=(csv.writer(csvfile))
     #writer=csv.DictWriter(csvfile,fieldnames=fieldname)
     writer.writerow(fieldname)
     writer.writerows(studentdata)
     csvfile.close()

with open("driveready.csv","r") as csvfile:
    reader = csv.reader(csvfile)
    print(csvfile.read())

def initfunc():
    global studentcount
    studentcount+=1
    while(studentcount<=5):
        choose=int(input("1)join , 2)reveling , 3)modifying"))
        if(choose==1):
            
            joiningfunc()
            print(studentdata)
            
        
#        elif(choose==3):
 #            modifyfunc
        else:
            print("invalid")
if (__name__== '__main__'):
    studentdata= []
    initfunc()
    
